# 🚀 Musify Repo Glow-Up Kit

Everything below is copy-paste ready. Do Section 1 first (takes 2 minutes and fixes your biggest discovery problem), then 2–4 as you have time.

---

## 1️⃣ GitHub "About" Box — paste this NOW

**How:** On your repo main page → click the ⚙️ gear icon next to **About** → paste description, add topics, tick "Use your GitHub Pages website" OFF, save.

### Description (recommended — lean into the music hook)

```
🎵 The privacy-first Android browser that loves music. Kotlin + Jetpack Compose + GeckoView. Zero telemetry, strict tracker blocking, HTTPS-first — and Spotify Web just plays. 🛡️
```

### Alternative A (technical crowd / r/androiddev, HN)

```
Native Android privacy browser in Kotlin & Jetpack Compose. Dual engine (GeckoView 135 + WebView), zero telemetry, ABP-grade content blocking, sandboxed downloads, 101 unit tests ✅
```

### Alternative B (short & punchy)

```
Block trackers. Play Spotify Web. Keep your data on-device. Open-source Android privacy browser built with Kotlin, Compose & GeckoView. 🎵🛡️
```

### Topics (add all 20 — GitHub's max; this is how people find you via topic pages)

```
android  kotlin  jetpack-compose  android-app  android-browser
browser  privacy  privacy-browser  ad-blocker  content-blocking
tracker-blocker  geckoview  webview  material3  kotlin-android
spotify  music  foss  open-source  security
```

### Website field

Leave blank for now. After you do Section 3, set it to: `https://github.com/adishxm/Musify/releases`

---

## 2️⃣ New README.md — full replacement (copy everything in the block)

> ⚠️ Before pasting: create a `docs/screenshots/` folder in your repo and drop 3–5 phone screenshots in (home, shields panel, tabs, Spotify Web playing). A README with screenshots gets *dramatically* more stars than a text wall. The image rows will render as soon as the files exist.

```markdown
<div align="center">

# 🎵 Musify

### The privacy-first Android browser that loves music.

**Zero telemetry. Strict tracker blocking. HTTPS-first. And Spotify Web that actually plays.**

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Android_8.0+-3DDC84?logo=android&logoColor=white)](#-download)
[![Kotlin](https://img.shields.io/badge/Kotlin-2.0.21-7F52FF?logo=kotlin&logoColor=white)](#-tech-stack)
[![UI](https://img.shields.io/badge/UI-Jetpack_Compose_M3-4285F4?logo=jetpackcompose&logoColor=white)](#-tech-stack)
[![Engine](https://img.shields.io/badge/Engine-GeckoView_135-FF7139?logo=firefoxbrowser&logoColor=white)](#-tech-stack)
[![Tests](https://img.shields.io/badge/Unit_Tests-101%2F101_passing-success)](#-building--testing)
[![Stars](https://img.shields.io/github/stars/adishxm/Musify?style=social)](https://github.com/adishxm/Musify/stargazers)

[**⬇️ Download**](#-download) · [**✨ Features**](#-features) · [**🛠️ Build**](#-building--testing) · [**🗺️ Roadmap**](#-roadmap) · [**🤝 Contribute**](#-contributing)

<!-- 📸 SCREENSHOTS: put real images in docs/screenshots/ and these render -->
| 🏠 Home | 🛡️ Shields | 🗂️ Tabs | 🎵 Spotify Web |
|:---:|:---:|:---:|:---:|
| <img src="docs/screenshots/home.png" width="200"> | <img src="docs/screenshots/shields.png" width="200"> | <img src="docs/screenshots/tabs.png" width="200"> | <img src="docs/screenshots/spotify.png" width="200"> |

</div>

---

## Why Musify?

Most mobile browsers phone home. Musify doesn't. It's an independent, general-purpose Android browser engineered for **transparent, measurable privacy** — no telemetry, no accounts, no cloud sync, no crypto tokens, no news feed. Just a fast, honest browser — that's also been painstakingly tuned so **Spotify Web playback works flawlessly** (Widevine DRM, desktop-mode recovery and all).

## ✨ Features

- 🕵️ **Zero telemetry, zero harvesting** — no behavioral analytics, no ad tracking, no cloud profile sync. All browsing data stays strictly on-device.
- 🛡️ **Privacy Shields** — engine-native strict protection against ad trackers, social trackers, cryptominers & fingerprinters.
- 🎵 **Spotify Web, verified working** — hardware Widevine DRM probing (`MediaDrm`), desktop-mode playback recovery, and measured capability badges instead of hardcoded hacks.
- 🌐 **HTTPS-first** — automatic HTTPS upgrades with an explicit warning before any cleartext HTTP load; cleartext disabled in Network Security Config.
- 🔒 **Strict TLS** — enforced certificate validation. Zero silent overrides, no blanket "proceed anyway" SSL button.
- 🗂️ **20-tab architecture** — deterministic tab cap prevents OOM crashes; engine sessions are lazy-allocated and destroyed on tab close.
- ♻️ **Zero-leak session recovery** — restores tabs after process death using only minimal metadata (UUID, URL, title, timestamps) — never DOM content, form entries, cookies or secrets.
- 🚫 **Filter-list pipeline** — memory-bounded offline ABP rule compiler, staged atomic activations, last-known-good rollback, transparent licensing/provenance screens.
- 🔍 **Anti-spoofing omnibar** — displays full verified origin (scheme, host, port) and decodes IDN homoglyphs to Punycode (`xn--…`).
- ⬇️ **Safe downloads** — user-confirmed, off-thread, sandboxed app storage with `FileProvider` mediation and executable threat badges.
- 🎛️ **Per-site control** — reversible per-origin shield exceptions, deny-by-default permissions, fail-closed external scheme protection.
- 📡 **AdGuard DNS companion layer** — system-wide Android Private DNS integration, segregated from in-page Shields counters.
- 🧪 **101/101 unit tests passing** across all development phases.
- 🆓 **Free & open source** — Apache 2.0, independent design & identity.

## ⬇️ Download

| APK | Best for |
|---|---|
| **[Musify.apk](../../raw/main/Musify.apk)** | Universal — any Android 8.0+ device |
| **[Musify-ARM64.apk](../../raw/main/Musify-ARM64.apk)** | Modern 64-bit phones (recommended) |
| **[Musify-Lite.apk](../../raw/main/Musify-Lite.apk)** | Low-storage & older devices |

Requires **Android 8.0 (API 26)** or later. Sideload, allow the install, done — no account needed.

## 🏗️ Tech Stack

| Layer | Choice |
|---|---|
| Language | **Kotlin 2.0.21** |
| UI | **Jetpack Compose** (Material 3, edge-to-edge) |
| Engine | Decoupled `EngineAdapter` → **GeckoView 135** (primary) + **AndroidX WebKit 1.12.1** (fallback) |
| Build | Gradle 8.13 (Kotlin DSL), AGP 8.13.2 |
| Target / Min SDK | **35 (Android 15)** / **26 (Android 8.0)** |
| JVM | Java 17 / 21 |

## 🛠️ Building & Testing

**Prerequisites:** Android Studio Ladybug/Meerkat (SDK 35, build-tools 35.0.0+), JDK 17 or 21.

```bash
# Run all unit tests (101 tests)
./gradlew testDebugUnitTest

# Debug / release APK
./gradlew assembleDebug
./gradlew assembleRelease

# Install on a connected device
./gradlew installDebug
```

## 🗺️ Roadmap

Development followed a phased, evidence-based plan — every phase ships with a written verification report in [`.brain/.report/`](.brain/.report/).

| Phase | Scope | Status |
|---|---|---|
| 00–02 | Foundation, engine feasibility, single-tab shell | ✅ Pass |
| 03–04 | Tabs, lifecycle, session recovery, history & bookmarks | ✅ Pass |
| 05–06 | Privacy Shields, filter-list pipeline & licensing gate | ✅ Pass |
| 07–08 | Downloads, permissions, hardening & memory profiling | ✅ Pass |
| 09 | Beta distribution & release readiness | ✅ Pass |
| 10 | **Spotify Web compatibility** — Widevine probe, desktop playback recovery, AdGuard DNS layer | ✅ Implementation verified |

## 🤝 Contributing

Issues and PRs are welcome! Found a site that breaks with Shields on? A playback edge case? Open an issue — measured capability reports > "it doesn't work."

## ⭐ Star History

[![Star History Chart](https://api.star-history.com/svg?repos=adishxm/Musify&type=Date)](https://star-history.com/#adishxm/Musify&Date)

## 📄 License

[Apache 2.0](LICENSE) — use it, fork it, ship it.

---

<div align="center">
If Musify earned a place on your home screen, a ⭐ tells others it's worth a look.
</div>
```

---

## 3️⃣ Create a real GitHub Release (10 min — big trust + reach win)

Right now your APKs are committed to the git repo. That bloats clones, and users trust **Releases** far more. Go to **Releases → Draft a new release**:

- **Tag:** `v1.0.0`
- **Title:** `Musify v1.0.0 — Privacy-first Android browser that loves music 🎵`
- **Attach:** all three APKs as release assets
- **Notes:**

```markdown
## Musify v1.0.0 — first public release 🎉

A privacy-first Android browser built with Kotlin, Jetpack Compose & GeckoView.

**Highlights**
- 🛡️ Strict tracker / cryptominer / fingerprint blocking (GeckoView ETP)
- 🎵 Spotify Web playback verified — Widevine DRM probing + desktop-mode recovery
- 🌐 HTTPS-first, strict TLS, zero telemetry
- 🗂️ 20-tab session management with zero-leak recovery
- 🚫 Offline ABP filter-list compiler with atomic rollback
- 📡 AdGuard DNS (Android Private DNS) companion layer
- 🧪 101/101 unit tests passing

**Pick your APK**
- `Musify.apk` — universal (any Android 8.0+)
- `Musify-ARM64.apk` — recommended for modern phones
- `Musify-Lite.apk` — low storage / older devices

**Known caveats:** physical-device Spotify playback is implementation-verified but still being validated across devices — report edge cases in Issues!
```

Then (optional but good for repo hygiene): remove the APK binaries from the git tree and link Releases from the README instead.

---

## 4️⃣ The "get views & stars" checklist (in order of impact)

| # | Action | Effort | Impact |
|---|---|---|---|
| 1 | Paste About description + 20 topics (Section 1) | 2 min | 🔥🔥🔥 — you currently have ZERO, so you don't appear in any topic search |
| 2 | Add 3–5 screenshots to the README | 15 min | 🔥🔥🔥 — visual repos convert visitors to stars; text-only repos bounce |
| 3 | Record a 20-sec screen GIF (open Spotify Web, play a song, toggle Shields) and put it at the top | 20 min | 🔥🔥🔥 |
| 4 | Create the v1.0.0 Release (Section 3) | 10 min | 🔥🔥 — watchers get notified; APKs become trustworthy |
| 5 | Set a **social preview image** (Settings → General → Social preview, 1280×640) — your "Neon Spotify Rings" icon on a dark gradient with the tagline | 10 min | 🔥🔥 — this is the image shown when your link is shared anywhere |
| 6 | Pin Musify on your GitHub profile | 1 min | 🔥 |
| 7 | Post it: **r/androidapps**, **r/fossdroid**, **r/privacy** (self-promo days), **Show HN** on Hacker News (Tue–Thu morning ET), X with #AndroidDev #Kotlin #FOSS, and a dev.to/Medium post — *"I built a privacy browser in Kotlin and made Spotify Web work"* (a build-story outperforms a bare link 10×) | 1–2 hrs | 🔥🔥🔥 |
| 8 | Add `CONTRIBUTING.md` + open 2–3 "good first issue"s | 30 min | 🔥 — signals an alive, welcoming project |
| 9 | Reply in threads where people ask for lightweight/private Android browsers or Spotify-web-player workarounds | ongoing | 🔥 |

**One honest warning:** don't buy stars or use star-bots. GitHub's spam detection removes them, and getting flagged kills your repo's credibility permanently. 50 real stars beat 5,000 fake ones.

---

## 5️⃣ Quick positioning note 💡

Your name says "music" but your README said "general-purpose browser" — that mismatch buries your best differentiator. The glow-up leans into it: **"privacy-first browser that loves music."** Brave has crypto, Firefox has an ecosystem, Musify has: *zero telemetry + Spotify Web that just works.* That's a story people remember and share.
